//var builder = WebApplication.CreateBuilder(args);

//// Add services to the container.
//builder.Services.AddControllersWithViews();
//builder.Services.AddHttpClient();
//var app = builder.Build();
//// MVC Project - Startup.cs

//void ConfigureServices(IServiceCollection services)
//{
//    // Add services to the container.
//    services.AddControllersWithViews();

//    // Add session services
//    services.AddSession(options =>
//    {
//        options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout duration
//        options.Cookie.HttpOnly = true; // Ensures that the session cookie is accessible only via HTTP
//        options.Cookie.IsEssential = true; // Marks the session cookie as essential for the app's functionality
//    });
//}


//// Configure the HTTP request pipeline.
//if (!app.Environment.IsDevelopment())
//{
//    app.UseExceptionHandler("/Home/Error");
//    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
//    app.UseHsts();
//}

//app.UseHttpsRedirection();
//app.UseStaticFiles();

//app.UseRouting();

//app.UseAuthorization();

//app.MapControllerRoute(
//    name: "default",
//    pattern: "{controller=SignUp}/{action=Login}/{id?}");

//app.Run();


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient();

// Add session services
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Set session timeout duration
    options.Cookie.HttpOnly = true; // Ensures that the session cookie is accessible only via HTTP
    options.Cookie.IsEssential = true; // Marks the session cookie as essential for the app's functionality
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

// Enable session middleware
app.UseSession(); // THIS LINE IS NECESSARY TO ENABLE SESSION

app.UseRouting();

app.UseAuthorization();

// Map the default route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=SignUp}/{action=Login}/{id?}");

app.Run();
