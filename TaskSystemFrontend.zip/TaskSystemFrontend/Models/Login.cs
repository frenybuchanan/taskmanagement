﻿namespace TaskSystemFrontend.Models
{
    public class Login
    {
        public string name { get; set; } 
        public string password { get; set; } 
    }
}
