﻿namespace TaskSystemFrontend.Models
{
    public class Role
    {


        public int roleId { get; set; }
        public string roleName { get; set; }


    }
}
