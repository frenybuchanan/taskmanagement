﻿namespace TaskSystemFrontend.Models
{
    public class Register
    {
 
            public string role { get; set; }
            public string uname { get; set; }
            public string gender { get; set; }
            public string email { get; set; }
            public int contact { get; set; }
            public string password { get; set; }
 
    }
}
