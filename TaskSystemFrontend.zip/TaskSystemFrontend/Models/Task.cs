﻿namespace TaskSystemFrontend.Models
{
    public class Task
    {

        public int userId { get; set; }
        public int taskId { get; set; }
        public string taskName { get; set; }
        public string description { get; set; }
        public DateOnly dueDate { get; set; }
        public string assignedTo { get; set; }
        public string Uname { get; set; }
        public string Status { get; set; }


    }
}
