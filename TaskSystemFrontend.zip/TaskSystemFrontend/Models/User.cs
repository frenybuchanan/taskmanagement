﻿namespace TaskSystemFrontend.Models
{
    public class User
    {

        public int userId { get; set; }
        public int roleId { get; set; }
        public string role { get; set; }
        public string uname { get; set; }
        public string gender { get; set; }
        public string email { get; set; }
        public int contact { get; set; }
        public string password { get; set; }



    }
}
