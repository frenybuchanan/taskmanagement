﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TaskSystemFrontend.Models;

namespace TaskSystemFrontend.Controllers
{
    public class ProfileController : Controller
    {
        private string url = " http://localhost:5037/api/Admin/";
        private readonly IHttpClientFactory client;
        public ProfileController(IHttpClientFactory httpClientFactory)
        {
            client = httpClientFactory;
        }
        public async Task<IActionResult> Index()
        {
            List<User> users = new List<User>();
            var cl = client.CreateClient();
            var response = await cl.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<List<User>>(result);

                if (data != null && data.Any())
                {
                    users = data;
                }
            }
            else
            {

                Console.WriteLine("Failed to fetch data from the API.");
            }

            return View(users);
        }
    }
}
