﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using TaskSystemFrontend.Models;

namespace TaskSystemFrontend.Controllers
{
    public class RoleController : Controller
    {

        private string url = "http://localhost:5037/api/Role/";
        private readonly IHttpClientFactory client;
        public RoleController(IHttpClientFactory httpClientFactory)
        {
            client = httpClientFactory;
        }
        public async Task<IActionResult> Index()
        {

            List<Role> roles = new List<Role>();
            var cl = client.CreateClient();
            var response = await cl.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<List<Role>>(result);
                if (data != null)
                {
                    roles = data;

                }

            }

            return View(roles);

        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Role r)
        {

            var cl = client.CreateClient();
            Console.WriteLine($"Roleid: {r.roleId}");
            var data = JsonConvert.SerializeObject(new
            {
                r.roleName
            });// converting data into JSON
            var content = new StringContent(data, Encoding.UTF8, "application/Json");
            var response = await cl.PostAsync(url, content);
            Console.WriteLine("Stop here");
            if (response.IsSuccessStatusCode)
            {

                ViewBag.SuccessMessage = "Data inserted Successfully";
                return RedirectToAction("Index");

            }


            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {

            Role r = new Role();
            var cl = client.CreateClient();
            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            Console.WriteLine($"response,{response}");
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Role>(result);
                if (data != null)
                {
                    r = data;
                }

            }
            return View(r);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(Role r)
        {
            Console.WriteLine($"RoleName: {r.roleId}");
            Console.WriteLine($"RoleName: {r.roleName}");
            var cl = client.CreateClient();

            var roleDTO = new
            {
                RoleName = r.roleName,
            };


            var data = JsonConvert.SerializeObject(roleDTO);
            var content = new StringContent(data, Encoding.UTF8, "application/Json");
            var response = await cl.PutAsync(url + r.roleId, content);
            Console.WriteLine("Stop here");
            if (response.IsSuccessStatusCode)
            {
                ViewBag.SuccessMessage = "Data Updated Successfully";
                return RedirectToAction("Index");

            }
            return View();

        }


        [HttpGet]
        public IActionResult Details(int id)
        {

            Role r = new Role();
            var cl = client.CreateClient();

            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Role>(result);
                if (data != null)
                {
                    r = data;
                }

            }

            return View(r);

        }


        [HttpGet]
        public IActionResult Delete(int id)
        {
            Role r = new Role();

            var cl = client.CreateClient();

            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Role>(result);
                if (data != null)
                {
                    r = data;
                }

            }

            return View(r);

        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {

            var cl = client.CreateClient();
            var response = await cl.DeleteAsync(url + id);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();

        }
    }



}