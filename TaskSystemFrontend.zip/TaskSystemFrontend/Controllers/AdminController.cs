﻿using System.Text;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TaskSystemFrontend.Models;

namespace TaskSystemFrontend.Controllers
{
    public class AdminController : Controller
    {
        private string url = "http://localhost:5037/api/Role/";
        private readonly IHttpClientFactory client;
        public AdminController(IHttpClientFactory httpClientFactory)
        {
            client = httpClientFactory;
        }
        public async Task<IActionResult> Index()
        {
            List<Role> roles = new List<Role>();
            var cl = client.CreateClient();
            var response = await cl.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<List<Role>>(result);
                if (data != null)
                {
                    roles = data;
                }
            }
            return View(roles);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Role r)
        {

            var cl = client.CreateClient();
            Console.WriteLine($"Roleid: {r.roleId}");
            var data = JsonConvert.SerializeObject(new
            {
                r.roleName
            });
            var content = new StringContent(data, Encoding.UTF8, "application/Json");
            var response = await cl.PostAsync(url, content);
            Console.WriteLine("Stop here");
            if (response.IsSuccessStatusCode)
            {
                ViewBag.SuccessMessage = "Data inserted Successfully";
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
