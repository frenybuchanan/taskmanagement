﻿using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages;
using Newtonsoft.Json;
using TaskSystemFrontend.Models;
using static System.Net.WebRequestMethods;
using Task = TaskSystemFrontend.Models.Task;

namespace TaskSystemFrontend.Controllers
{
    public class SignUpController : Controller
    {

        private string url = " http://localhost:5037/api/Admin/";
        private readonly IHttpClientFactory client;
        public SignUpController(IHttpClientFactory httpClientFactory)
        {
            client = httpClientFactory;
        }



        public async Task<IActionResult> Index()
        {
            List<User> users = new List<User>();
            var cl = client.CreateClient();
            var response = await cl.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                var data = JsonConvert.DeserializeObject<List<User>>(result);

                if (data != null && data.Any())
                {
                    users = data;
                }
            }
            else
            {

                Console.WriteLine("Failed to fetch data from the API.");
            }

            return View(users);
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(User newUser)
        {

            var cl = client.CreateClient();
            var response = await cl.PostAsJsonAsync(url, newUser);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View(newUser);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {

            User r = new User();
            var cl = client.CreateClient();
            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            Console.WriteLine($"response,{response}");
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<User>(result);
                if (data != null)
                {
                    r = data;
                }

            }
            return View(r);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(User r)
        {

            var cl = client.CreateClient();
            var token = Request.Cookies["jwt"];
            var UserDTO = new
            {
                userId = r.userId,
                roleId = r.roleId,
                role = r.role,
                uname = r.uname,
                gender = r.gender,
                email = r.email,
                contact = r.contact,
                password = r.password

            };

            var data = JsonConvert.SerializeObject(UserDTO);
            var content = new StringContent(data, Encoding.UTF8, "application/Json");
            var response = await cl.PutAsync(url + r.userId, content);
            Console.WriteLine("Stop here");
            if (response.IsSuccessStatusCode)
            {
                ViewBag.SuccessMessage = "Data Updated Successfully";
                return RedirectToAction("Index");

            }
            return View();

        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            User r = new User();

            var cl = client.CreateClient();

            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<User>(result);
                if (data != null)
                {
                    r = data;
                }

            }

            return View(r);

        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cl = client.CreateClient();
            var response = await cl.DeleteAsync(url + id);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ModelState.AddModelError("", "Could not delete task");
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult RegisterDash()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> RegisterDash(User model)
        {

            var api = "http://localhost:5037/api/User/register";
            var cl = client.CreateClient();
            var content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");

            try
            {

                var response = await cl.PostAsync(api, content);


                if (response.IsSuccessStatusCode)
                {

                    var responseContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Registration successful: " + responseContent);
                    return RedirectToAction("Login", "SignUp");
                }
                else
                {

                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Registration failed: " + errorContent);
                    ModelState.AddModelError("", "Registration failed. Please try again.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception during registration: " + ex.Message);
                ModelState.AddModelError("", "An error occurred. Please try again.");
            }

            return View(model);
        }


        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(Models.Login model)
        {
            if (ModelState.IsValid)
            {
                var token = await AuthenticateUserAsync(model.name, model.password);
                if (string.IsNullOrEmpty(token))
                {
                    ModelState.AddModelError("", "Invalid username or password.");
                    return View(model);
                }

                Response.Cookies.Append("jwt", token, new CookieOptions { HttpOnly = true, Secure = true });
                var role = GetRoleFromToken(token);
                var username = GetUsernameFromToken(token);
                if (role == "admin")
                {
                    return RedirectToAction("AdminDashboard", "SignUp");
                }
                else if (role == "Hello")
                {
                    return RedirectToAction("Dashboard", "SignUp");
                }
                else if (role == "Manager")
                {
                    return RedirectToAction("ManagerDashboard", new { username = username });
                }
                else if (role == "User")
                {
                    return RedirectToAction("UserDashboard", new { username = username });
                }

                return RedirectToAction("Index", "Home");
            }

            return View(model);
        }
        private string GetUsernameFromToken(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(token) as JwtSecurityToken;
            return jsonToken?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Name)?.Value;
        }
        private string GetRoleFromToken(string token)
        {
            var handler = new JwtSecurityTokenHandler();
            var jsonToken = handler.ReadToken(token) as JwtSecurityToken;
            return jsonToken?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role).Value;
        }

        private async Task<string> AuthenticateUserAsync(string username, string password)
        {
            var cl = client.CreateClient();
            var loginData = JsonConvert.SerializeObject(new { name = username, password = password });

            var content = new StringContent(loginData, Encoding.UTF8, "application/json");
            var response = await cl.PostAsync("http://localhost:5037/api/User/login", content);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadAsStringAsync();
                dynamic jsonResponse = JsonConvert.DeserializeObject(result);
                return jsonResponse?.token;
            }

            return null;
        }
        public IActionResult Dashboard()
        {
            return View();
        }
        public IActionResult ManagerDashboard(string username)
        {
            ViewBag.Username = username;
            return RedirectToAction("Index", "Task");
          
        }



        public async Task<List<Task>> GetTasksByManager(string assignedTo)
        {
            var cl = client.CreateClient();
            var response = await cl.GetAsync($"http://localhost:5037/api/Task/manager?assignedTo={assignedTo}");

            List<Task> tasks = new List<Task>();

            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                tasks = JsonConvert.DeserializeObject<List<Task>>(result);
            }

            return tasks;
        }



        [HttpGet]
        public async Task<IActionResult> UserDashboard(string username)
        {
            ViewBag.Username = username;
            return RedirectToAction("Index", "User");
        }


        public async Task<List<Task>> GetTasksByUser(string assignedTo)
        {
            var cl = client.CreateClient();
            var response = await cl.GetAsync($"http://localhost:5037/api/Task/manager?assignedTo={assignedTo}");

            List<Task> tasks = new List<Task>();

            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                tasks = JsonConvert.DeserializeObject<List<Task>>(result);
            }

            return tasks;
        }

        public IActionResult AdminDashboard()
        {
            return View();
        }
        public IActionResult LogoutDash()
        {
            HttpContext.SignOutAsync();
            return RedirectToAction("Login", "SignUp");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Remove("JWTToken");
            return RedirectToAction("Login");
        }


    }
}
