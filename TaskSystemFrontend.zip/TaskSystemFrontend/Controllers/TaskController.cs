﻿using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.VisualBasic;
using Newtonsoft.Json;
using TaskSystemFrontend.Models;
using Task = TaskSystemFrontend.Models.Task;

namespace TaskSystemFrontend.Controllers
{
    public class TaskController : Controller
    {

        private string url = "http://localhost:5037/api/Task/";
        private readonly IHttpClientFactory client;
        public TaskController(IHttpClientFactory httpClientFactory)
        {
            client = httpClientFactory;
        }
        public async Task<IActionResult> Index()
        {
            List<Task> tasks = new List<Models.Task>();
            var cl = client.CreateClient();
            var response = await cl.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<List<Task>>(result);
                if (data != null)
                {
                    tasks = data;
                }
            }
            return View(tasks);
        }
        [HttpGet]
        public async Task<IActionResult> Create()
        {

            var cl = client.CreateClient();
            var response = await cl.GetAsync("http://localhost:5037/api/Admin/");

            List<User> usernameList = new List<User>();

            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine(responseContent);


                usernameList = JsonConvert.DeserializeObject<List<User>>(responseContent);
                foreach (var user in usernameList)
                {
                    Console.WriteLine(user.uname);

                }

            }

            ViewBag.UsernameList = usernameList;
            foreach (var user in usernameList)
            {
                Console.WriteLine(user.uname);

            }

            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Create(Task r)
        {
            Console.WriteLine("run to thay che");
            var token = Request.Cookies["jwt"];
            var cl = client.CreateClient();
            cl.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            var data = JsonConvert.SerializeObject(new
            {
                TaskId = r.taskId,
                TaskName = r.taskName,
                Description = r.description,
                DueDate = r.dueDate,
                UserId = r.userId,
                Status = r.Status,
                AssignedTo = r.assignedTo,
                Uname = r.Uname,
            });

            Console.WriteLine(data.ToString());
            var content = new StringContent(data, Encoding.UTF8, "application/Json");
            var response = await cl.PostAsync(url, content);

            Console.WriteLine(response);
            Console.WriteLine("Stop here");
            if (response.IsSuccessStatusCode)
            {
                ViewBag.SuccessMessage = "Data inserted Successfully";
                return RedirectToAction("Index");
            }
            return View();
        }





        [HttpGet]
        public IActionResult Edit(int id)
        {

            Task r = new Task();
            var cl = client.CreateClient();
            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            Console.WriteLine($"response,{response}");
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Task>(result);
                if (data != null)
                {
                    r = data;
                }

            }
            return View(r);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(Task r)
        {

            var cl = client.CreateClient();

            var TaskDTO = new
            {
                taskId = r.taskId,
                taskName = r.taskName,
                description = r.description,
                dueDate = r.dueDate,
                userId = r.userId,
                status = r.Status,
                assignedTo = r.assignedTo,
                managerUsername = r.Uname,
            };


            var data = JsonConvert.SerializeObject(TaskDTO);
            var content = new StringContent(data, Encoding.UTF8, "application/Json");// String Content converts the data into formatted content
            var response = await cl.PutAsync(url + r.taskId, content);
            Console.WriteLine("Stop here");
            if (response.IsSuccessStatusCode)
            {
                ViewBag.SuccessMessage = "Data Updated Successfully";
                return RedirectToAction("Index");

            }
            return View();

        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            Task r = new Task();

            var cl = client.CreateClient();

            HttpResponseMessage response = cl.GetAsync(url + id).Result;

            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Task>(result);
                if (data != null)
                {
                    r = data;
                }

            }

            return View(r);

        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {

            var cl = client.CreateClient();
            var response = await cl.DeleteAsync(url + id);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            return View();

        }


    }
}
