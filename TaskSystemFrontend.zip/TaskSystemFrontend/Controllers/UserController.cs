﻿using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Task = TaskSystemFrontend.Models.Task;

using System.Text;
using System.Diagnostics;

public class UserController : Controller
{
    private readonly IHttpClientFactory _client;
    private string _url = "http://localhost:5037/assignedTo/";

    public UserController(IHttpClientFactory httpClientFactory)
    {
        _client = httpClientFactory;
    }

    public async Task<IActionResult> Index(int userId)
    {
        List<Task> tasks = new List<TaskSystemFrontend.Models.Task>();

        var client = _client.CreateClient();
        var token = Request.Cookies["jwt"];
        var handler = new JwtSecurityTokenHandler();

        // Parse the token to extract the userId
        var jwtToken = handler.ReadJwtToken(token);
        string id;
        var userIdClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier);
        if (userIdClaim != null)
        {
            id = userIdClaim?.Value;
        }
        else
        {
            id = "0";
        }

        var response = await client.GetAsync($"{_url}{id}");
        if (response.IsSuccessStatusCode)
        {
            string result = await response.Content.ReadAsStringAsync();
            var data = JsonConvert.DeserializeObject<List<Task>>(result);

            if (data != null)
            {
                tasks = data;
            }
        }
        else
        {
            ViewBag.ErrorMessage = "Could not retrieve tasks for this user.";
        }

        return View(tasks);
    }

    // GET: Edit task
    [HttpGet]
    public async Task<IActionResult> Edit(int taskId)
    {
        var client = _client.CreateClient();
        var token = Request.Cookies["jwt"];
        var handler = new JwtSecurityTokenHandler();

        // Parse the token to get the user ID
        var jwtToken = handler.ReadJwtToken(token);
        string userId = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized();
        }
        Console.WriteLine(taskId);
        var response = await client.GetAsync($"http://localhost:5037/api/Task/{taskId}");

        Console.WriteLine(response);

        if (response.IsSuccessStatusCode)
        {
            var result = await response.Content.ReadAsStringAsync();
            var task = JsonConvert.DeserializeObject<Task>(result);
            Console.WriteLine(task.ToString());
            if (task != null)
            {
                return View(task); 
            }
        }

        ViewBag.errormessage = "Could not retrieve the task for editing.";
        return View();
    }
  
    [HttpPost]
    public async Task<IActionResult> Edit(int taskId, Task task)
    {
        
        var token = Request.Cookies["jwt"];
        var handler = new JwtSecurityTokenHandler();
        var jwtToken = handler.ReadJwtToken(token);
        string userId = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier)?.Value;

        if (string.IsNullOrEmpty(userId))
        {
            return Unauthorized();
        }

        if (task == null || task.taskId != taskId)
        {
            ModelState.AddModelError("", "Invalid task data.");
            return View(task);  // Return the view with the current task data
        }
        Console.WriteLine("to");
        var url = $"http://localhost:5037/api/Task/updateTask/{task.taskId}";
        Console.WriteLine(url);
        var cl = _client.CreateClient();
        Console.WriteLine("bdhu");

        var taskUpdateData = new
        {
            task.Status 
        };

        Console.WriteLine("thay");
        var jsonContent = JsonConvert.SerializeObject(taskUpdateData);
        var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
        Console.WriteLine("j");
        var response = await cl.PutAsync(url , content);
        Console.WriteLine(response);
        

        if (!response.IsSuccessStatusCode)
        {
            string responseBody = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"Failed to update task status. Response: {responseBody}");
            ModelState.AddModelError("", "There was an error saving the changes.");
            return View(task); 
        }
        else
        {
            Console.WriteLine("ne");
            string responseBody = await response.Content.ReadAsStringAsync();
            Console.WriteLine($"Task updated successfully. Response body: {responseBody}");

            var updatedTask = JsonConvert.DeserializeObject<Task>(responseBody);
            Console.WriteLine($"Updated task status: {updatedTask.Status}");

            return RedirectToAction("Index");
        }

       

    }





}
