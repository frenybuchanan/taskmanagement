﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TaskSystem.Models;

public partial class TaskSystemContext : DbContext
{
    public TaskSystemContext()
    {
    }

    public TaskSystemContext(DbContextOptions<TaskSystemContext> options)
        : base(options)
    {
    }

    public virtual DbSet<AdminTable> AdminTables { get; set; }

    public virtual DbSet<MainUser> MainUsers { get; set; }

    public virtual DbSet<ManagerTask> ManagerTasks { get; set; }

    public virtual DbSet<RoleTable> RoleTables { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=ISGTRNG-21Y37S2;Database=TaskSystem;User ID=SA;Password=Welcome01;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AdminTable>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("AdminTable");

            entity.Property(e => e.AdminId).HasColumnName("AdminID");
            entity.Property(e => e.Email)
                .HasMaxLength(10)
                .IsFixedLength();
            entity.Property(e => e.Password)
                .HasMaxLength(10)
                .IsFixedLength();
        });

        modelBuilder.Entity<MainUser>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__MainUser__1788CCACB73A4D73");

            entity.ToTable("MainUser");

            entity.HasIndex(e => e.Uname, "UQ_UName").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Role)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.Uname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("UName");
        });

        modelBuilder.Entity<ManagerTask>(entity =>
        {
            entity.HasKey(e => e.TaskId).HasName("PK__ManagerT__7C6949D18C1F94B4");

            entity.Property(e => e.TaskId).HasColumnName("TaskID");
            entity.Property(e => e.AssignedTo)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Description)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.TaskName)
                .HasMaxLength(50)
                .IsUnicode(false);
            entity.Property(e => e.Uname)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasDefaultValue("default_user");
            entity.Property(e => e.UserId).HasColumnName("UserID");
        });

        modelBuilder.Entity<RoleTable>(entity =>
        {
            entity.HasKey(e => e.RoleId);

            entity.ToTable("RoleTable");

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
