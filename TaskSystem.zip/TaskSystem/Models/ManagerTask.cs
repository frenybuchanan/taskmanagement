﻿using System;
using System.Collections.Generic;

namespace TaskSystem.Models;

public partial class ManagerTask
{
    public int UserId { get; set; }

    public int TaskId { get; set; }

    public string TaskName { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateOnly DueDate { get; set; }

    public string AssignedTo { get; set; } = null!;

    public string Status { get; set; } = null!;

    public string Uname { get; set; } = null!;
}
