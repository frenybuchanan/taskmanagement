﻿namespace TaskSystem.Models.DTO
{
    public class UserDTO
    {
        public int UserId { get; set; }

        public int RoleId { get; set; }

        public string Role { get; set; } = null!;

        public string Uname { get; set; } = null!;

        public string Gender { get; set; } = null!;

        public string Email { get; set; } = null!;

        public int Contact { get; set; }

        public string Password { get; set; } = null!;
    }
}
