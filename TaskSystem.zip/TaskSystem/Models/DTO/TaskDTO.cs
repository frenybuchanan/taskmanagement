﻿namespace TaskSystem.Models.DTO
{
    public class TaskDTO
    {
        public int UserId { get; set; }

        public int TaskId { get; set; }

        public string TaskName { get; set; } = null!;

        public string Description { get; set; } = null!;

        public DateOnly DueDate { get; set; }

        public string AssignedTo { get; set; } = null!;
        public string Uname { get; set; } = null!;
        public string Status { get; set; } = null!;

        //  public virtual MainUser User { get; set; }    }
    }
}