﻿namespace TaskAPI.Models.DTO
{
    public class RoleDTO
    {
        public string RoleName { get; set; }

        public int RoleId { get; set; }
        // public int UserId { get; internal set; }
    }
}
