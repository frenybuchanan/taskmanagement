﻿namespace TaskSystem.Models.DTO
{
    public class StatusDto
    {
        public string? Status { get; set; }
    }
}

