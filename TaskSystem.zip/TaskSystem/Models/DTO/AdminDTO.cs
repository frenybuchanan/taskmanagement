﻿namespace TaskSystem.Models.DTO
{
    public class AdminDTO
    {
        public int AdminId { get; set; }

        public string Email { get; set; } = null!;

        public string? Password { get; set; }
    }
}
