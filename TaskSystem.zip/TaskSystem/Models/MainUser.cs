﻿using System;
using System.Collections.Generic;

namespace TaskSystem.Models;

public partial class MainUser
{
    public int UserId { get; set; }

    public int RoleId { get; set; }

    public string Role { get; set; } = null!;

    public string? Uname { get; set; }

    public string Gender { get; set; } = null!;

    public string Email { get; set; } = null!;

    public int Contact { get; set; }

    public string Password { get; set; } = null!;
}
