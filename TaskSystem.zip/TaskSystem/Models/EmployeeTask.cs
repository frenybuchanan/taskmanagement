﻿using System;
using System.Collections.Generic;

namespace TaskSystem.Models;

public partial class EmployeeTask
{
    public int UserId { get; set; }

    public int TaskId { get; set; }

    public string TaskName { get; set; } = null!;

    public string Description { get; set; } = null!;

    public DateOnly DueDate { get; set; }

    public string Status { get; set; } = null!;

    public virtual MainUser User { get; set; } = null!;
}
