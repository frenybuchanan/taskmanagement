﻿using TaskSystem.Models.DTO;

namespace TaskSystem.Service
{
    public interface IuserService
    {
        public Task<string> RegisterUserAsync(UserDTO model);
        public Task<string> LoginUserAsync(string Name, string password);
    }
}
