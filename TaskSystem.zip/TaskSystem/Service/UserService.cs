﻿
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

using TaskSystem.Models.DTO;
using TaskSystem.Models;
using TaskSystem.Service;

namespace TaskA.Service
{
    public class UserService : IuserService
    {
        private readonly TaskSystemContext _context;
        private readonly string _jwtSecretKey;

        public UserService(TaskSystemContext context, IConfiguration config)
        {
            _context = context;
            _jwtSecretKey = config["JwtSettings:SecretKey"]; // to get secret from appsettings.json
        }


        public async Task<string> LoginUserAsync(string username, string password)
        {
            var user = await _context.MainUsers.FirstOrDefaultAsync(u => u.Uname == username);
            Console.WriteLine(user.ToString());
            var istrue = VerifyPassword(password, user.Password);
            Console.WriteLine(istrue);
            if (user == null || !VerifyPassword(password, user.Password))
            {
                throw new UnauthorizedAccessException("Invalid credentials");
            }

            return GenerateJwtToken(user);
        }

        private string HashPassword(string password)
        {
            return Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: Encoding.UTF8.GetBytes("YourSaltHere"), // Use a unique salt for each user
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));
        }

        private bool VerifyPassword(string password, string storedHash)
        {
            var hashedPassword = HashPassword(password);
            return hashedPassword == storedHash;
        }

        private string GenerateJwtToken(MainUser user)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier,user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.Uname),
                new Claim(ClaimTypes.Role, user.Role.ToString()),
                  new Claim(JwtRegisteredClaimNames.Aud, "MyAppUsers"), // Audience claim
                new Claim(JwtRegisteredClaimNames.Iss, "MyApp"), // Issuer claim
                new Claim(JwtRegisteredClaimNames.Exp, DateTimeOffset.UtcNow.AddMinutes(30).ToUnixTimeSeconds().ToString())
                };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSecretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: null,
                audience: null,
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        public async Task<MainUser> GetUserByUsernameAsync(string username)
        {
            // Assuming you have a Users table in your database
            return await _context.MainUsers
                .FirstOrDefaultAsync(u => u.Uname == username);  // Fetch user by username
        }

        public async Task<string> RegisterUserAsync(UserDTO dt)
        {

            var r = await _context.RoleTables.FirstOrDefaultAsync(i => i.RoleName == dt.Role);
            Console.WriteLine(r);
            if (r == null)
            {
                return "Data not found";
            }
            var hashedPassword = HashPassword(dt.Password);
            var user = new MainUser()
            {
                RoleId = r.RoleId,
                Uname = dt.Uname,
                Password = hashedPassword,
                Email = dt.Email,
                Role = dt.Role,
                Gender = dt.Gender,
                Contact = dt.Contact

            };
            _context.MainUsers.Add(user);
            await _context.SaveChangesAsync();

            return null;
        }
        
    }
}