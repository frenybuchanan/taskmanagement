﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskAPI.Models.DTO;
using TaskSystem.Models;
using TaskSystem.Models.DTO;

namespace TaskSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        private readonly TaskSystemContext context;

        public RoleController(TaskSystemContext context)
        {
            this.context = context;
        }
        [HttpGet]

        public async Task<ActionResult<List<RoleTable>>> GetRole() {
            var data = await context.RoleTables.ToListAsync();
            return Ok(data);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<RoleTable>> GetById(int id)
        {

            var d = await context.RoleTables.FindAsync(id);
            if (d == null)
            {
                return NotFound();
            }
            return Ok(d);

        }
        [HttpPost]
        public async Task<ActionResult<RoleTable>> AddTask(RoleDTO rt)
        {

            RoleTable rto = new RoleTable
            {
                RoleId = rt.RoleId,
                RoleName = rt.RoleName,
            };
            await context.RoleTables.AddAsync(rto);
            await context.SaveChangesAsync();

            return Ok(rto);


        }


        [HttpPut("{id}")]
        public async Task<string> UpdateUser(int id, RoleDTO dto)//Task<ActionResult<RoleTable>>
        {
            var d = await context.RoleTables.Where((i) => i.RoleId == id).FirstOrDefaultAsync();
            if (d == null)
            {
                return "User data not found";
            }
            d.RoleName = dto.RoleName;


            await context.SaveChangesAsync();
            return "User data updated successfully ";

        }


        [HttpDelete("{id}")]
        public async Task<string> DeleteUser(int id)
        {
            var d = await context.RoleTables.Where(i => i.RoleId == id).FirstOrDefaultAsync();

            if (d == null)  // Check if the user is not found
            {
                return "User data not found";
            }

            context.RoleTables.Remove(d);  // Correctly remove the entity from the DbSet
            await context.SaveChangesAsync();

            return "User deleted successfully";
        }

    }
}
