﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskA.Service;
using TaskSystem.Models;
using TaskSystem.Models.DTO;
using TaskSystem.Service;

namespace TaskA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly TaskSystemContext _db;

        private readonly UserService _userService;

        public UserController(TaskSystemContext db, IuserService userService)
        {
            _db = db;
            _userService = (UserService?)userService;

        }

    

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserDTO dto)
        {
            // Validate input (optional but recommended)
            if (dto == null || string.IsNullOrEmpty(dto.Uname) || string.IsNullOrEmpty(dto.Password))
            {
                return BadRequest("Invalid data.");
            }

            // Call RegisterUserAsync and get the result message
            var result = await _userService.RegisterUserAsync(dto);

            if (result == null)
            {
                // If registration is successful, return Ok with the success message
                return Ok(dto);
            }
            else
            {
                return BadRequest();
            }
            // If registration fails (e.g., username already exists), return BadRequest with the error message
            //  return BadRequest(result); // Returning the message from the service
        }
       

        [HttpPost("login")]
        public async Task<IActionResult> Login(UserCredentials u)
        {
            var token = await _userService.LoginUserAsync(u.name, u.password);
            if (token == null)
            {
                return Unauthorized("Invalid username or password.");
            }
            return Ok(new { Token = token });
        }

        // [Authorize(Roles  = "Tester")]
        [Authorize(Roles = "Hello")]
        [HttpGet("tester-page")]
        public IActionResult GetTesterPage()
        {
            return Ok("Welcome, Tester!");
        }


        public class UserCredentials
        {
            public string name { get; set; }
            public string password { get; set; }

        }

    }

}
