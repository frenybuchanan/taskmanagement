﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskSystem.Models.DTO;
using TaskSystem.Models;
using TaskAPI.Models.DTO;


// Api for admin to manage the users
namespace TaskA.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly TaskSystemContext db;

        public AdminController(TaskSystemContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public async Task<ActionResult<List<MainUser>>> getUsers()
        {
            var data = await db.MainUsers.ToListAsync();
            return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<MainUser>> GetById(int id)
        {

            var d = await db.MainUsers.FindAsync(id);
            if (d == null)
            {
                return NotFound();
            }
            return Ok(d);

        }


        [HttpPost]
        public async Task<ActionResult<MainUser>> AddTask(UserDTO rt)
        {
           
            MainUser rto = new MainUser
            {
                RoleId = rt.RoleId,
                Role = rt.Role,  // Assuming you might also store the role name in MainUser
                Uname = rt.Uname,
                Gender = rt.Gender,
                Email = rt.Email,
                Contact = rt.Contact,
                Password = rt.Password,
            };

            await db.MainUsers.AddAsync(rto);
            await db.SaveChangesAsync();

            return Ok(rto);
        }

        [HttpPut("{id}")]
        public async Task<string> UpdateUser(int id, UserDTO dto)
        {
            var d = await db.MainUsers.Where((i) => i.UserId == id).FirstOrDefaultAsync();
            if (d == null)
            {
                return "User data not found";
            }

            d.Uname = dto.Uname;
            d.Email = dto.Email;
            d.Password = dto.Password;
            d.Gender = dto.Gender;
            d.Contact = dto.Contact;
            d.Role = dto.Role;
            await db.SaveChangesAsync();
            return "User data updated successfully ";


        }


        [HttpDelete("{id}")]
        public async Task<string> deleteUser(int id)
        {
            var user = await db.MainUsers
                .Where(i => i.UserId == id)
                .FirstOrDefaultAsync();

  
            db.MainUsers.Remove(user);
            await db.SaveChangesAsync();

            return "User deleted successfully";
        }



    }
}