﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TaskAPI.Models.DTO;
using TaskSystem.Models;
using TaskSystem.Models.DTO;

namespace TaskSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly TaskSystemContext context;

        public TaskController(TaskSystemContext context)
        {
            this.context = context;
        }
        [HttpGet]
        public async Task<ActionResult<List<ManagerTask>>> GetTasks()
        {
            var data = await context.ManagerTasks.ToListAsync();
            return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ManagerTask>> GetTaskById(int id)
        {
            var data = await context.ManagerTasks.FindAsync(id);
            if (data == null)
            {
                return NotFound();
            }
            return Ok(data);
        }

        [HttpPost]
        public async Task<ActionResult<ManagerTask>> AddTask(TaskDTO rt)
        {

            ManagerTask rto = new ManagerTask
            {
                UserId = rt.UserId,
                //TaskId = rt.TaskId,
                TaskName = rt.TaskName,
                Description = rt.Description,
                DueDate = rt.DueDate,
                AssignedTo = rt.AssignedTo,
                Status = rt.Status,
                Uname = rt.Uname
            };

            Console.WriteLine(rto.ToString());
            await context.ManagerTasks.AddAsync(rto);
            await context.SaveChangesAsync();

            return Ok(rto);
        }



        [HttpPut("{id}")]
        public async Task<ActionResult<ManagerTask>> UpdateTask(int id, TaskDTO rt)
        {
            ManagerTask rto = new ManagerTask
            {
                UserId = rt.UserId,
                TaskId = rt.TaskId,
                TaskName = rt.TaskName,
                Description = rt.Description,
                DueDate = rt.DueDate,
                AssignedTo = rt.AssignedTo,
                Status = rt.Status,
                Uname = rt.Uname
            };
            if (id != rt.UserId)
            {
                return BadRequest();
            }
            context.Entry(rto).State = EntityState.Modified;
            await context.SaveChangesAsync();
            return Ok(rto);
        }

        [HttpDelete("{id}")]
        public async Task<string> DeleteUser(int id)
        {
            var d = await context.ManagerTasks.Where(i => i.TaskId == id).FirstOrDefaultAsync();

            if (d == null)  // Check if the user is not found
            {
                return "User data not found";
            }

            context.ManagerTasks.Remove(d);  
            await context.SaveChangesAsync();

            return "User deleted successfully";
        }

        [HttpGet("/assignedTo/{assignedToId}")]
        public async Task<ActionResult<List<ManagerTask>>> GetTasksByAssignedTo(string assignedToId)
        {
            var tasks = await context.ManagerTasks
                .Where(t => t.AssignedTo == assignedToId)
                .ToListAsync();

            if (tasks == null || tasks.Count == 0)
            {
                return NotFound("No tasks found for the specified user.");
            }

            return Ok(tasks);
        }


        [HttpPut("updateTask/{id}")]
        public async Task<ManagerTask> updateStatus(int id, StatusDto status)
        {
            var t = await context.ManagerTasks.FirstOrDefaultAsync(i => i.TaskId == id);
            if (t == null)
            {
                return new ManagerTask();
            }
            t.Status = status?.Status ?? "Not Updated";
            await context.SaveChangesAsync();
            return t;

        }
    }
}
